// Binary Search Tree in C++
//https://gist.github.com/mycodeschool/9465a188248b624afdbf
#include<iostream>
using namespace std;

struct BST_Node
{
	int data;
	BST_Node* left;
	BST_Node* right;
};

BST_Node* GetNewNode(int data)
{
	BST_Node* newNode = new BST_Node();
	newNode->data = data;
	newNode->left = newNode->right = NULL;
	return newNode;
}

BST_Node* Insert(BST_Node* root, int data)
{
	if (root == NULL) //If tree is empty
	{
		root = GetNewNode(data);		
	}
	else if(data <= root->data)//If new data is less than or equal to the root's data
	{
		root->left = Insert(root->left, data); //Place it on the left of the root
	}
	else  //If data is greater than or equal to the root's data
	{
		root->right = Insert(root->right, data); //Place it on the right of the root
	}
	return root;
}

BST_Node* FindMin(BST_Node* root)
{
	while (root->left != NULL) root = root->left;
	return root;
}

struct BST_Node* Delete(struct BST_Node *root, int data)
{
	if (root == NULL) return root; //If the root is null, return the root
	else if (data < root->data) root->left = Delete(root->left, data); //If the data were wanting to delete is less than the root's data, keep searching the left node
	else if (data > root->data) root->right = Delete(root->right, data);//If the data were wanting to delete is greater than the roots data, keep searching to the right node
	else //Delete the node
	{
		//No child
		if (root->left == NULL && root->right == NULL)
		{
			delete root;
			root = NULL;
		}

		//One child
		else if (root->left == NULL)
		{
			struct BST_Node *temp = root;
			root = root->right;
			delete temp;
		}
		else if (root->right == NULL)
		{
			struct BST_Node* temp = root;
			root = root->left;
			delete temp;
		}

		//Two Children
		else
		{
			struct BST_Node* temp = FindMin(root->right);
			root->data = temp->data;
			root->right = Delete(root->right, temp->data);
		}
	}
	return root;
}

int main ()
{
	BST_Node* root = NULL; //Pointer to the root node, which is empty at first

	//Insert a bunch of nodes with data
	Insert(root,97);
	Insert(root, 82);
	Insert(root, 38);
	Insert(root, 61);
	Insert(root, 10);
	Insert(root, 14);
	Insert(root, 70);
	Insert(root, 99);
	Insert(root, 32);
	Insert(root, 63);
}